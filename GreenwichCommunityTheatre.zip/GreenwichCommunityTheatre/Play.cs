﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Play
    {
        private int playid;
        private string playname;
        private string playdesc;
        private string playimage;
        private string playmainimage;

        public Play(string playname, string playimage)
        {
            this.playname = playname;
            this.playimage = playimage;
        }

        public Play(int playid, string playname, string playdesc, string playmainimage)
        {
            this.playid = playid;
            this.playname = playname;
            this.playdesc = playdesc;
            this.playmainimage = playmainimage;
        }
        public Play(int playid)
        {
            this.playid = playid;
        }
        public Play(int playid,string playname, string playimage)
        {
            this.playid = playid;
            this.playname = playname;
            this.playimage = playimage;
        }
        public Play(int playid, string playname)
        {
            this.playid = playid;
            this.playname = playname;
        }

        public int Playid
        {
            get
            {
                return playid;
            }

            set
            {
                playid = value;
            }
        }

        public string Playname
        {
            get
            {
                return playname;
            }

            set
            {
                playname = value;
            }
        }

        public string Playdesc
        {
            get
            {
                return playdesc;
            }

            set
            {
                playdesc = value;
            }
        }

        public string Playimage
        {
            get
            {
                return playimage;
            }

            set
            {
                playimage = value;
            }
        }

        public string Playmainimage
        {
            get
            {
                return playmainimage;
            }

            set
            {
                playmainimage = value;
            }
        }
    }
}