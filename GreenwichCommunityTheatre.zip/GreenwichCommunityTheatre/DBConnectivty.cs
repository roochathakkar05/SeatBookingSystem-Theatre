﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class DBConnectivty
    {
        private static OleDbConnection GetConnection()
        {
            string conn;
            conn = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=C:\Users\ROOCHA THAKKAR\Documents\gctdb.mdb";
            return new OleDbConnection(conn);
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Play> LoadPopularPlay()
        {
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_name, plays.[play_image] FROM plays WHERE plays.popularaty = 'Y' ; ";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Play p = new Play( myReader["play_name"].ToString(), myReader["play_image"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadSelectedPlay(string url)
        {
            int x = 0;
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_id FROM plays WHERE plays.[play_image]= '" + url + "';";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    x = int.Parse(myReader["play_id"].ToString());;
                }
                return x;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return x;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Play> LoadSchedule()
        {
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT schedule.schedule_id, schedule.play_id, plays.play_name, plays.[play_image] FROM show_slot INNER JOIN (plays INNER JOIN schedule ON plays.play_id = schedule.play_id) ON show_slot.show_slot_id = schedule.show_slot_id";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Play p = new Play(myReader["play_name"].ToString(), myReader["play_image"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Schedule> LoadSelectedNSPlay(int id)
        {
            List<Schedule> schedule = new List<Schedule>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT schedule_id, schedule.playdate, show_slot.Day, show_slot.showtime, plays.play_main_image, plays.play_name, plays.play_desc, schedule.play_id FROM show_slot INNER JOIN (plays INNER JOIN schedule ON plays.play_id = schedule.play_id) ON show_slot.show_slot_id = schedule.show_slot_id WHERE schedule.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Schedule s = new Schedule(int.Parse(myReader["schedule_id"].ToString()),int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString(), myReader["play_desc"].ToString(), myReader["play_main_image"].ToString(), myReader["showtime"].ToString(), myReader["Day"].ToString(), myReader["playdate"].ToString());
                    schedule.Add(s);
                }
                return schedule;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Play> LoadSelectedPPPlay(int id)
        {
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_id, plays.play_name, plays.play_desc, plays.play_main_image FROM plays WHERE plays.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Play p = new Play(int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString(), myReader["play_desc"].ToString(), myReader["play_main_image"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Customer> Login(string email, string pass)
        {
            List<Customer> login = new List<Customer>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email, customer.customer_pass FROM customer WHERE customer.customer_email='"+ email +"' AND customer.customer_pass='"+ pass +"';";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Customer g = new Customer(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["customer_pass"].ToString());
                    login.Add(g);
                }
                return login;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Individual SingleUser(int id)
        {
            Individual g = null;
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email ,individual.fname, individual.lname, individual.gender FROM customer INNER JOIN individual ON customer.customer_id = individual.customer_id WHERE customer.customer_id = " + id + ";";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    g = new Individual(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["fname"].ToString(), myReader["lname"].ToString(), myReader["gender"].ToString());
                }
                return g;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Institution InstitutionUser(int id)
        {
            Institution g = null;
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email, institution.institution_name, institution.instituion_type FROM customer INNER JOIN institution ON customer.customer_id = institution.customer_id WHERE customer.customer_id= " + id + ";";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    g = new Institution(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["institution_name"].ToString(), myReader["instituion_type"].ToString());
                }
                return g;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Schedule LoadPlayUserConfirmed(int id)
        {
            Schedule s = null;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT schedule_id,schedule.playdate, show_slot.Day, show_slot.showtime, plays.play_main_image, plays.play_name, plays.play_desc, schedule.play_id FROM show_slot INNER JOIN (plays INNER JOIN schedule ON plays.play_id = schedule.play_id) ON show_slot.show_slot_id = schedule.show_slot_id WHERE schedule.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    s = new Schedule(int.Parse(myReader["schedule_id"].ToString()),int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString(), myReader["play_desc"].ToString(), myReader["play_main_image"].ToString(), myReader["showtime"].ToString(), myReader["Day"].ToString(), myReader["playdate"].ToString());
                    
                }
                return s;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Institution InstitutionUserBooking(int id)
        {
            Institution g = null;
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email,customer.customer_phone,customer.customer_pass, institution.institution_name, institution.instituion_type FROM customer INNER JOIN institution ON customer.customer_id = institution.customer_id WHERE customer.customer_id= " + id + ";";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    g = new Institution(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["customer_phone"].ToString(), myReader["customer_pass"].ToString(), myReader["institution_name"].ToString(), myReader["instituion_type"].ToString());
                }
                return g;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Individual SingleUserBooking(int id)
        {
            Individual g = null;
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email ,customer.customer_phone,customer_pass,individual.fname, individual.lname, individual.gender FROM customer INNER JOIN individual ON customer.customer_id = individual.customer_id WHERE customer.customer_id = " + id + ";";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    g = new Individual(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["customer_phone"].ToString(), myReader["customer_pass"].ToString(), myReader["fname"].ToString(), myReader["lname"].ToString(), myReader["gender"].ToString());
                }
                return g;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Seat> Bookings(int schedule_id)
        {
            List<Seat> seats = new List<Seat>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT booking.seatid, booking.schedule_id, booking.status FROM booking WHERE booking.schedule_id=" + schedule_id + ";";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Seat g = new Seat(int.Parse(myReader["seatid"].ToString()), myReader["status"].ToString(), int.Parse(myReader["schedule_id"].ToString()));
                    seats.Add(g);
                }
                return seats;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Review LoadRating(int id)
        {
            Review x = null;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT Avg(review.rating) AS AvgOfrating FROM review GROUP BY review.play_id HAVING review.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    x = new Review(double.Parse(myReader["AvgOfrating"].ToString()));
                }
                return x;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Review> LoadReview(int id)
        {
            List<Review> review = new List<Review>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT review.review FROM review WHERE review.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                  Review x = new Review(myReader["review"].ToString());
                  review.Add(x);
                }
                return review;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadBookeSeatNo(int id)
        {
            int x = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT Count(*) AS numofbookings FROM booking WHERE booking.schedule_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    x = int.Parse(myReader["numofbookings"].ToString()); ;
                }
                return x;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return x;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static double Loadprice(int id,int schedule)
        {
            double x = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT playprice.price FROM playprice WHERE playprice.schedule_id=" + schedule + "AND playprice.Band_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    x = int.Parse(myReader["price"].ToString()); ;
                }
                return x;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return x;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddBooking(int seatid, int scheduleid, string status, int odid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO booking(seatid,schedule_id,status,order_detail_id) VALUES ('" + seatid + "','" + scheduleid + "','" + status + "'," + odid + ")";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static Order ExistingOrder(int customerid)
        {
            Order g = null;
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT order.order_id, order.customer_id, order.status FROM [order] WHERE order.customer_id="+ customerid+" AND order.status='nc';";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    g = new Order(int.Parse(myReader["order_id"].ToString()), int.Parse(myReader["customer_id"].ToString()), myReader["status"].ToString());
                }
                return g;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddOrder(int customerid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO [order](customer_id,status) VALUES (" + customerid + ",'nc')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadTheOrderDetailID(int orderid, int playidd)
        {
            int playid = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT order_detail.order_detail_id FROM order_detail WHERE order_detail.order_id="+orderid+ " AND order_detail.play_id=" + playidd + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    playid = int.Parse(myReader["order_detail_id"].ToString());
                }
                return playid;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return 0;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadNumOfBookedSeat(int orderdetail_id)
        {
            int playid = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT order_detail.num_of_seats FROM order_detail WHERE order_detail.order_detail_id=" + orderdetail_id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    playid = int.Parse(myReader["num_of_seats"].ToString());
                }
                return playid;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return 0;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadOrderDetailPrice(int orderdetail_id)
        {
            int playid = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT order_detail.price FROM order_detail WHERE order_detail.order_detail_id=" + orderdetail_id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    playid = int.Parse(myReader["price"].ToString());
                }
                return playid;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return 0;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadThePlayID(int id)
        {
            int playid = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT schedule.play_id FROM schedule WHERE schedule.schedule_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    playid = int.Parse(myReader["play_id"].ToString());
                }
                return playid;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return 0;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddOrderDetail(int orderid,int scheduleid, int numofseats, int price)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO order_detail(order_id,play_id,num_of_seats,price) VALUES (" + orderid + "," + scheduleid + "," + numofseats + "," + price + ")";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static void UpdateSeatandPrice(int seats, int price, int odid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "UPDATE order_detail SET order_detail.num_of_seats =" + seats + ", order_detail.price ="+price+" WHERE order_detail.order_detail_id =" + odid + ";";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<OrderDetail> CartDetails(int orderid)
        {
            List<OrderDetail> cart = new List<OrderDetail>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT order.order_id, order_detail.order_detail_id, order_detail.num_of_seats, plays.play_name, plays.play_image, order_detail.price FROM plays INNER JOIN ([order] INNER JOIN order_detail ON order.order_id = order_detail.order_id) ON plays.play_id = order_detail.play_id WHERE order.customer_id=" + orderid + "AND status = 'nc';";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    OrderDetail g = new OrderDetail(int.Parse(myReader["order_id"].ToString()), int.Parse(myReader["order_detail_id"].ToString()), int.Parse(myReader["num_of_seats"].ToString()), double.Parse(myReader["price"].ToString()), myReader["play_name"].ToString(), myReader["play_image"].ToString());
                    cart.Add(g);
                }
                return cart;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void RemoveOrderDetail(int odid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "DELETE order_detail.order_detail_id, order_detail.order_id, order_detail.play_id, order_detail.num_of_seats, order_detail.price, order_detail.order_detail_id FROM order_detail WHERE order_detail.order_detail_id=" + odid + ";";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Shipping> Shipping()
        {
            List<Shipping> seats = new List<Shipping>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT shipping.shipping_id, shipping.type, shipping.price FROM shipping"; 
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Shipping g = new Shipping(int.Parse(myReader["shipping_id"].ToString()), myReader["type"].ToString(), double.Parse(myReader["price"].ToString()));
                    seats.Add(g);
                }
                return seats;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Shipping ShippingType(int ship_id)
        {
            Shipping ship = null;
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT shipping.shipping_id, shipping.type, shipping.price FROM shipping WHERE shipping.shipping_id = " + ship_id;
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    ship = new Shipping(int.Parse(myReader["shipping_id"].ToString()), myReader["type"].ToString(), double.Parse(myReader["price"].ToString()));
                }
                return ship;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void ConfirmOrder(int shipping,int odid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "UPDATE [order] SET [order].shipping_id ="+ shipping + ", [order].status ='c' WHERE order_id =" + odid + ";";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddIndividual(string fname, string lname, string gender,int customer_id)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO individual(customer_id,fname,lname,gender) VALUES (" + customer_id + ",'" + fname + "','" + lname + "','" + gender + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddCustomer(string email, string phone, string pass, string address)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO customer(customer_email,customer_phone,customer_pass,customer_address) VALUES ('" + email + "','" + phone + "','" + pass + "','" + address + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static int LoadNewCustomerId(string email)
        {
            int x = 0;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT customer_id FROM customer WHERE customer_email='" + email + "';";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    x = int.Parse(myReader["customer_id"].ToString()); ;
                }
                return x;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return x;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddInstitution(string iname, string type, int customer_id)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO institution(customer_id,institution_name,instituion_type) VALUES (" + customer_id + ",'" + iname + "','" + type + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<int> LoadWatchedPlays(int customer_id)
        {
            List<int> seats = new List<int>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT DISTINCT(order_detail.play_id) FROM plays INNER JOIN ([order] INNER JOIN order_detail ON order.order_id = order_detail.order_id) ON plays.play_id = order_detail.play_id WHERE order.customer_id=" + customer_id + ";";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    int g = (int.Parse(myReader["play_id"].ToString()));
                    seats.Add(g);
                }
                return seats;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static Play LoadWatchedPlayDetails(int id)
        {
            Play play = null;
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_id, plays.play_name, plays.play_desc, plays.[play_image] FROM plays WHERE plays.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    play = new Play(int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString(), myReader["play_desc"].ToString(), myReader["play_image"].ToString());
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddReview(int play_id, string review,int rating, int customer_id)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO review(customer_id,play_id,review,rating) VALUES (" + customer_id + "," + play_id + ",'" + review + "'," + rating + ")";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddPayment(int order_id, string mop, int amount, string status)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO payment(order_id,mode_of_payment,amount,status) VALUES (" + order_id + ",'" + mop + "'," + amount + ",'"+ status +"')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Play> ReviewPlay(int id)
        {
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_id, plays.play_name, plays.play_desc, plays.play_main_image FROM plays WHERE plays.play_id=" + id + ";";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Play p = new Play(int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString(), myReader["play_desc"].ToString(), myReader["play_main_image"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        // END CUSTOMER 
        //----------------------------------------------------------------------------------------------------------
        public static List<Play> LoadAllPlays()
        {
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_id,plays.play_name, plays.[play_image] FROM plays; ";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Play p = new Play(int.Parse(myReader["play_id"].ToString()),myReader["play_name"].ToString(), myReader["play_image"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void RemovePlay(int odid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "DELETE plays.play_id, plays.play_name, plays.play_desc, plays.play_image, plays.popularity, plays.play_main_image FROM plays WHERE plays.play_id=" + odid + ";";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddPlay(string name, string description, string mainimage, string thumbnail)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO plays(play_name,play_desc,play_image,play_main_image) VALUES ('" + name + "','" + description + "','" + thumbnail + "','" + mainimage + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Order> LoadAllorders()
        {
            List<Order> play = new List<Order>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT order_id,customer_id ,shipping_id FROM [order] WHERE order.status = 'c'; ";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Order p = new Order(int.Parse(myReader["order_id"].ToString()), int.Parse(myReader["customer_id"].ToString()), int.Parse(myReader["shipping_id"].ToString()));
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<OrderDetail> LoadOrderDetails(int orderid)
        {
            List<OrderDetail> cart = new List<OrderDetail>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT order.order_id, order_detail.order_detail_id, order_detail.num_of_seats, order.shipping_id, plays.play_name, plays.play_image, order_detail.price, payment.status FROM (plays INNER JOIN ([order] INNER JOIN order_detail ON order.order_id = order_detail.order_id) ON plays.play_id = order_detail.play_id) INNER JOIN payment ON order.order_id = payment.order_id WHERE order.order_id=" + orderid + " AND order.status = 'c';";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    OrderDetail g = new OrderDetail(int.Parse(myReader["order_id"].ToString()), int.Parse(myReader["order_detail_id"].ToString()), int.Parse(myReader["num_of_seats"].ToString()), double.Parse(myReader["price"].ToString()), int.Parse(myReader["shipping_id"].ToString()),myReader["play_name"].ToString(), myReader["play_image"].ToString(), myReader["status"].ToString());
                    cart.Add(g);
                }
                return cart;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void CompleteOrder(int odid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "UPDATE [order] INNER JOIN payment ON order.order_id = payment.order_id SET [order].status = 'a', payment.status = 'Paid' WHERE order.order_id=" + odid + ";";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Schedule> LoadWeeklySchedule()
        {
            List<Schedule> schedule = new List<Schedule>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT schedule.schedule_id, schedule.playdate, show_slot.Day, show_slot.showtime, plays.play_main_image, plays.play_name,plays.play_desc,schedule.play_id FROM show_slot INNER JOIN (plays INNER JOIN schedule ON plays.play_id = schedule.play_id) ON show_slot.show_slot_id = schedule.show_slot_id;";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Schedule s = new Schedule(int.Parse(myReader["schedule_id"].ToString()), int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString(), myReader["play_desc"].ToString(), myReader["play_main_image"].ToString(), myReader["showtime"].ToString(), myReader["Day"].ToString(), myReader["playdate"].ToString());
                    schedule.Add(s);
                }
                return schedule;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void ClearSchedule()
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "DELETE schedule.schedule_id FROM schedule WHERE (((schedule.schedule_id) Is Not Null))";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Play> LoadAllPlaysCB()
        {
            List<Play> play = new List<Play>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT plays.play_name, plays.play_id FROM plays;";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Play p = new Play(int.Parse(myReader["play_id"].ToString()), myReader["play_name"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Show_slot> LoadShowSlotCB()
        {
            List<Show_slot> play = new List<Show_slot>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT show_slot.show_slot_id, show_slot.day, show_slot.showtime FROM show_slot;";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Show_slot p = new Show_slot(int.Parse(myReader["show_slot_id"].ToString()), myReader["day"].ToString(), myReader["showtime"].ToString());
                    play.Add(p);
                }
                return play;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddSchedule(int play, int showslot, string date)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO schedule(play_id,show_slot_id,playdate) VALUES (" + play + "," + showslot + ",'" + date + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static void AddPrice(int schedule_id, int pbanda, int band_id)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO playprice(schedule_id,Band_id,price) VALUES (" + schedule_id + "," + band_id + "," + pbanda + ") ; ";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Individual> LoadSingleUser()
        {
            List<Individual> user = new List<Individual>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email ,individual.fname, individual.lname, individual.gender FROM customer INNER JOIN individual ON customer.customer_id = individual.customer_id ; ";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                   Individual g = new Individual(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["fname"].ToString(), myReader["lname"].ToString(), myReader["gender"].ToString());
                   user.Add(g);
                }
                return user;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------
        public static List<Institution> LoadInstitutionUser()
        {
            List<Institution> user = new List<Institution>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT customer.customer_id, customer.customer_email, institution.institution_name, institution.instituion_type FROM customer INNER JOIN institution ON customer.customer_id = institution.customer_id ;";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Institution g = new Institution(int.Parse(myReader["customer_id"].ToString()), myReader["customer_email"].ToString(), myReader["institution_name"].ToString(), myReader["instituion_type"].ToString());
                    user.Add(g);
                }
                return user;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //----------------------------------------------------------------------------------------------------------



    }
}