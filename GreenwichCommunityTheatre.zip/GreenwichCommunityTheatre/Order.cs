﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Order
    {
        private int orderid;
        private int customerid;
        private int shippingid;
        private string status;

        public Order(int orderid, int customerid, int shippingid, string status)
        {
            this.Orderid = orderid;
            this.Customerid = customerid;
            this.Shippingid = shippingid;
            this.Status = status;
        }
        public Order(int orderid, int customerid, string status)
        {
            this.Orderid = orderid;
            this.Customerid = customerid;
            this.Status = status;
        }
        public Order(int orderid, int customerid, int shippingid)
        {
            this.Orderid = orderid;
            this.Customerid = customerid;
            this.Shippingid = shippingid;
        }
        public int Orderid
        {
            get
            {
                return orderid;
            }

            set
            {
                orderid = value;
            }
        }

        public int Customerid
        {
            get
            {
                return customerid;
            }

            set
            {
                customerid = value;
            }
        }

        public int Shippingid
        {
            get
            {
                return shippingid;
            }

            set
            {
                shippingid = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }
    }
}