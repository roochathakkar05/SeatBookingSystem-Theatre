﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Customer
    {
        private int customer_id;
        private string customer_email;
        private string customer_pass;
        private string customer_phone;

        public Customer(int customer_id, string customer_email, string customer_phone, string customer_pass)
        {
            this.customer_id = customer_id;
            this.customer_email = customer_email;
            this.customer_pass = customer_pass;
            this.customer_phone = customer_phone;
        }
        public Customer(int customer_id, string customer_email, string customer_pass)
        {
            this.customer_id = customer_id;
            this.customer_email = customer_email;
            this.customer_pass = customer_pass;
        }
        public Customer(int customer_id, string customer_email)
        {
            this.customer_id = customer_id;
            this.customer_email = customer_email;
        }

        public Customer(int customer_id)
        {
            this.customer_id = customer_id;
        }
        public int Customer_id
        {
            get
            {
                return customer_id;
            }

            set
            {
                customer_id = value;
            }
        }

        public string Customer_email
        {
            get
            {
                return customer_email;
            }

            set
            {
                customer_email = value;
            }
        }

        public string Customer_pass
        {
            get
            {
                return customer_pass;
            }

            set
            {
                customer_pass = value;
            }
        }

        public string Customer_phone
        {
            get
            {
                return customer_phone;
            }

            set
            {
                customer_phone = value;
            }
        }
    }
}