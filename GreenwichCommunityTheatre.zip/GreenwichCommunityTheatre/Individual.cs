﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Individual:Customer
    {
        private string fname;
        private string lname;
        private string gender;

        public Individual(int ci, string e,string fname, string lname, string gender):base(ci,e)
        {
            this.fname = fname;
            this.lname = lname;
            this.gender = gender;
        }
        public Individual(int ci, string e, string p, string ph, string fname, string lname, string gender) : base(ci, e, p,ph)
        {
            this.fname = fname;
            this.lname = lname;
            this.gender = gender;
        }

        public string Fname
        {
            get
            {
                return fname;
            }

            set
            {
                fname = value;
            }
        }

        public string Lname
        {
            get
            {
                return lname;
            }

            set
            {
                lname = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }
    }
}