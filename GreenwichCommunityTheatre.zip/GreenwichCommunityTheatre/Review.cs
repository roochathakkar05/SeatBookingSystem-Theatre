﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Review
    {
        private string reviewwritten;
        private double rating;
        private int review_id;

        public Review(string reviewwritten)
        {
            this.reviewwritten = reviewwritten;
        }
        public Review( double rating)
        {
            this.rating = rating;

        }

        public double Rating
        {
            get
            {
                return rating;
            }

            set
            {
                rating = value;
            }
        }

        public int Review_id
        {
            get
            {
                return review_id;
            }

            set
            {
                review_id = value;
            }
        }

        public string Reviewwritten
        {
            get
            {
                return reviewwritten;
            }

            set
            {
                reviewwritten = value;
            }
        }
    }
}