﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class ReviewPlay : System.Web.UI.Page
    {
        List<Play> play;
        int play_id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                play_id = int.Parse(Session["ReviewPlayID"].ToString());
                play = DBConnectivty.ReviewPlay(play_id);
                for(int i = 0;i<play.Count; i++)
                {
                    Image1.ImageUrl = play[i].Playmainimage;
                    playtitle.Text = play[i].Playname;
                    Label1.Text = play[i].Playdesc;
                }
                
            }
        }
      
        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text == "")
            {
                Label2.Text = "Please make a review";
            }
            else
            {

                int cust_id = int.Parse(Session["customer"].ToString());
                int rating = int.Parse(DropDownList1.SelectedValue.ToString());
                string review = TextBox1.Text;
                DBConnectivty.AddReview(play_id, review, rating, cust_id);
                Response.Redirect("HomePage.aspx");

            }

        }
        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            Session["customer"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}