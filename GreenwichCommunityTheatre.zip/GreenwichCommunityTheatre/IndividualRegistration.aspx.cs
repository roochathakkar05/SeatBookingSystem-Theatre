﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class IndividualRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your First Name";
                Label1.ForeColor = System.Drawing.Color.Red;
            }
            else if (TextBox2.Text == "")
            {
                Label2.Visible = true;
                Label2.Text = "Please enter your Last Name";
                Label2.ForeColor = System.Drawing.Color.Red;
            }
            else if (TextBox3.Text == "")
            {
                Label3.Visible = true;
                Label3.Text = "Please enter your Phone Number";
                Label3.ForeColor = System.Drawing.Color.Red;
            }
            else if (TextBox4.Text == "")
            {
                Label4.Visible = true;
                Label4.Text = "Please enter your Email";
                Label4.ForeColor = System.Drawing.Color.Red;
            }
            else if (TextBox5.Text == "")
            {
                Label5.Visible = true;
                Label5.Text = "Please enter your Password";
                Label5.ForeColor = System.Drawing.Color.Red;
            }
            else if (TextBox6.Text == "")
            {
                Label6.Visible = true;
                Label6.Text = "Please re-enter your Password";
                Label6.ForeColor = System.Drawing.Color.Red;
            }
            else if (TextBox7.Text == "")
            {
                Label7.Visible = true;
                Label7.Text = "Please enter your address";
                Label7.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                string fname = TextBox1.Text;
                string lname = TextBox2.Text;
                string phone = TextBox4.Text;
                string email = TextBox3.Text;
                string password = TextBox5.Text;
                string cpassword = TextBox6.Text;
                string address = TextBox7.Text;
                string gender = DropDownList1.SelectedValue.ToString();

                if(password == cpassword)
                {
                    int cust_id = DBConnectivty.LoadNewCustomerId(email);
                    if (cust_id == 0)
                    {
                        Label6.Visible = true;
                        Label6.Text = "The email is already being used please use another email.";
                        Label6.ForeColor = System.Drawing.Color.Red;
                    }
                    else
                    {
                        DBConnectivty.AddCustomer(email, phone, password, address);
                        cust_id = DBConnectivty.LoadNewCustomerId(email);
                        DBConnectivty.AddIndividual(fname, lname, gender, cust_id);
                        Response.Redirect("Default.aspx");
                    }

                }
                else
                {
                    Label6.Visible = true;
                    Label6.Text = "The passwords you entered do not match";
                    Label6.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}