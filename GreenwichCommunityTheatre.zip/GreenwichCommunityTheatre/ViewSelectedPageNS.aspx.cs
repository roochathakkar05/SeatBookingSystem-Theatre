﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class ViewSelectedPageNS : System.Web.UI.Page
    {
        List<Schedule> SelectedPlay = new List<Schedule>();
        int schedule_id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                int selectedurl = int.Parse(Session["playimgurlNS"].ToString());
                SelectedPlay = DBConnectivty.LoadSelectedNSPlay(selectedurl);

                for (int i = 0; i < SelectedPlay.Count; i++)
                {
                    Image1.ImageUrl = SelectedPlay[i].Playmainimage;
                    playtitle.Text = SelectedPlay[i].Playname;
                    Label1.Text = SelectedPlay[i].Playdesc;
                    string _Date = SelectedPlay[i].Date;
                    DateTime dt = Convert.ToDateTime(_Date);
                    string FDate = dt.ToString("dd-MMM-yyyy");
                    Label2.Text = FDate;
                    Label3.Text = SelectedPlay[i].Day;
                    Label4.Text = SelectedPlay[i].Showtime;
                    schedule_id = SelectedPlay[i].Id;
                    Session["schedule_id"] = schedule_id;
                }
            }
            int NumberofBookings = DBConnectivty.LoadBookeSeatNo(schedule_id);
            if (NumberofBookings == 84)
            {
                Label5.Text = "No seat are available. We have a full house!";
                Label5.Visible = true;
                Button1.Visible = false;
            }
            else
            {
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string type = Session["customertype"].ToString();
            if(type == "institution")
            {
                Response.Redirect("ConfirmDetails.aspx");
            }
            else
            {
                Response.Redirect("ConfirmDetailsIndividual.aspx");
            }
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            Session["customer"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}