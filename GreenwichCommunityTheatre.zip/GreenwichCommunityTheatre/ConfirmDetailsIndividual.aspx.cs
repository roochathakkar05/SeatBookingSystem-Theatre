﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class ConfirmDetailsIndividual : System.Web.UI.Page
    {
        Schedule scheduled = null;
        string username;
        string type;
        Individual user;
        int schedule_id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                int selectedurl = int.Parse(Session["playimgurlNS"].ToString());
                scheduled = DBConnectivty.LoadPlayUserConfirmed(selectedurl);
                Label6.Text = scheduled.Showtime;
                Label7.Text = scheduled.Playname;
                Label8.Text = scheduled.Day;
                string _Date = scheduled.Date;
                DateTime dt = Convert.ToDateTime(_Date);
                string FDate = dt.ToString("dd-MMM-yyyy");
                Label9.Text = FDate;
                username = Session["customer"].ToString();
                type = Session["customertype"].ToString();
                schedule_id = int.Parse(Session["schedule_id"].ToString());
                if (type == "individual")
                {
                    user = DBConnectivty.SingleUserBooking(int.Parse(username));
                    Label1.Text = user.Fname;
                    Label2.Text = user.Lname;
                    Label3.Text = user.Customer_email;
                    Label4.Text = user.Customer_phone;
                }
                else
                {

                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["totalprice"] = 0;
            Session["bookedseats"] = 0;
            Response.Redirect("SelectSeat.aspx");

        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            Session["customer"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}