﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class OrderDetail
    {
        private int order_id;
        private int orderdetail_id;
        private int numberofseats;
        private double price;
        private string playname;
        private string playimage;
        private int shipping_id;
        private string paymentstatus;

        public OrderDetail(int order_id, int orderdetail_id, int numberofseats, double price, string playname, string playimage)
        {
            this.order_id = order_id;
            this.orderdetail_id = orderdetail_id;
            this.numberofseats = numberofseats;
            this.price = price;
            this.playname = playname;
            this.playimage = playimage;
        }
        public OrderDetail(int order_id, int orderdetail_id, int numberofseats, double price, int shipping_id,string playname, string playimage, string paymentstatus)
        {
            this.order_id = order_id;
            this.orderdetail_id = orderdetail_id;
            this.numberofseats = numberofseats;
            this.price = price;
            this.playname = playname;
            this.playimage = playimage;
            this.shipping_id = shipping_id;
            this.paymentstatus = paymentstatus;
        }
        public int Order_id
        {
            get
            {
                return order_id;
            }

            set
            {
                order_id = value;
            }
        }

        public int Orderdetail_id
        {
            get
            {
                return orderdetail_id;
            }

            set
            {
                orderdetail_id = value;
            }
        }

        public int Numberofseats
        {
            get
            {
                return numberofseats;
            }

            set
            {
                numberofseats = value;
            }
        }

        public double Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }

        public string Playname
        {
            get
            {
                return playname;
            }

            set
            {
                playname = value;
            }
        }

        public string Playimage
        {
            get
            {
                return playimage;
            }

            set
            {
                playimage = value;
            }
        }

        public int Shipping_id
        {
            get
            {
                return shipping_id;
            }

            set
            {
                shipping_id = value;
            }
        }

        public string Paymentstatus
        {
            get
            {
                return paymentstatus;
            }

            set
            {
                paymentstatus = value;
            }
        }
    }
}