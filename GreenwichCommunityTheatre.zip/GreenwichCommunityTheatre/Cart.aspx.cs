﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class Cart : System.Web.UI.Page
    {
        List<OrderDetail> cartdetails;
        string subprice;
        int grandtotal;
        int price;
        int id;
        int order_id;
        List<Shipping> ship;
        double sprice;
        int totalprice;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                if (!Page.IsPostBack)
                {
                    grandtotal = 0;
                    CBSHIPPING.DataSource = DBConnectivty.Shipping();
                    CBSHIPPING.DataTextField = "type";
                    CBSHIPPING.DataValueField = "shippingid";
                    CBSHIPPING.DataBind();
                    Session["shipid"] = 1;
                }
                cartdetails = DBConnectivty.CartDetails(int.Parse(Session["customer"].ToString()));
                if(cartdetails.Count == 0)
                {
                    Label2.Text = "You have no pending orders.";
                    Table1.Visible = false;
                }
                for (int j = 0; j < cartdetails.Count; j++)
                {
                    createdetail(j);
                    if(j == 4)
                    {
                         price = 0;
                    }
                    else
                    {
                        price = int.Parse(cartdetails[j].Price.ToString());
                    }
                    grandtotal = grandtotal + price;
                    Session["GrandTotal"] = grandtotal;
                    order_id = cartdetails[j].Order_id;
                    Session["PaidOrderId"] = order_id;
                    Total.Text = "£ " + Session["GrandTotal"].ToString();
                }
                

            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Button sourceButton = sender as Button;
            string id = sourceButton.ID;
            string[] values = id.Split('n');
            int orderdetailid = int.Parse(values[1]);
           // Label1.Text = orderdetailid.ToString();
            DBConnectivty.RemoveOrderDetail(orderdetailid);
            Response.Redirect("Cart.aspx");
        }
        public void createdetail(int i)
        {
            Image img = new Image();
            img.ImageUrl = cartdetails[i].Playimage;
            img.Width = 100;
            img.Height = 100;
            Label label = new Label();
            label.Text = cartdetails[i].Playname;
            Label label1 = new Label();
            label1.Text = cartdetails[i].Numberofseats.ToString();
            //
            Label label2 = new Label();
            if (i == 4)
            {
                subprice = "£ " + 0;
                Label2.Text = "Discount coupon book for four plays get one free has been applied. ";
                label2.Text = subprice;
            }
            else
            {
                string subprice = "£ " + cartdetails[i].Price.ToString();
                label2.Text = subprice;
            }    
            
            Button btn = new Button();
            btn.ID = "btn" + cartdetails[i].Orderdetail_id;
            btn.Text = "Remove";
            btn.Click += Button1_Click;

            TableRow row = new TableRow();
            TableCell cell2 = new TableCell();
            cell2.Controls.Add(img);
            TableCell cell3 = new TableCell();
            cell3.Controls.Add(label);
            TableCell cell4 = new TableCell();
            cell4.Controls.Add(label1);
            TableCell cell5 = new TableCell();
            cell5.Controls.Add(label2);
            TableCell cell6 = new TableCell();
            cell6.Controls.Add(btn);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);
            row.Cells.Add(cell5);
            row.Cells.Add(cell6);
            Table1.Rows.Add(row);
        }

        protected void CBSHIPPING_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = int.Parse(CBSHIPPING.SelectedValue);
            ship = DBConnectivty.Shipping();
            int idd = id - 1;
            sprice = ship[idd].Price;
            
            Session["shipid"] = ship[idd].Shippingid;
            Label3.Text = "£ "+ sprice.ToString();
            grandtotal = int.Parse(Session["GrandTotal"].ToString());
            totalprice = grandtotal + int.Parse(sprice.ToString());
            Total.Text = "£ " + totalprice.ToString();
            Session["Pricewithshipping"] = totalprice;
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            string mod = DropDownList1.SelectedValue;
            if (DropDownList1.SelectedValue == "Credit Card")
            {
                if((TextBox1.Text == "")|| (TextBox2.Text == "")|| (TextBox3.Text == "")|| (TextBox4.Text == ""))
                {
                    Label5.Text = "Enter a valid credit card number";
                }
                else
                {
                    DBConnectivty.AddPayment(order_id, mod, int.Parse(Session["Pricewithshipping"].ToString()), "Paid");
                    DBConnectivty.ConfirmOrder(int.Parse(Session["shipid"].ToString()), order_id);
                    Response.Redirect("PrintPage.aspx");
                }
            }
            else
            {

                DBConnectivty.AddPayment(order_id, mod, int.Parse(Session["Pricewithshipping"].ToString()), "Unpaid");
                DBConnectivty.ConfirmOrder(int.Parse(Session["shipid"].ToString()), order_id);
                Response.Redirect("PrintPage.aspx");
            }

           
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedValue == "Credit Card")
            {
                Label4.Visible = true;
                TextBox1.Visible = true;
                TextBox2.Visible = true;
                TextBox3.Visible = true;
                TextBox4.Visible = true;
            }
            else
            {
                Label4.Visible = false;
                TextBox1.Visible = false;
                TextBox2.Visible = false;
                TextBox3.Visible = false;
                TextBox4.Visible = false;
            }
        }
        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            Session["customer"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}