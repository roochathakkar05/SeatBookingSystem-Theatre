﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class SelectSeat : System.Web.UI.Page
    {
        List<ImageButton> BandA = new List<ImageButton>();
        List<ImageButton> BandB = new List<ImageButton>();
        List<ImageButton> BandC = new List<ImageButton>();
        List<ImageButton> BandALL = new List<ImageButton>();
        int schedule_id;
        ImageButton bookedseat;
        double totalprice = 0;
        int bookedseats = 0;
        int requestedseats;
        int customer_id;
        List<Seat> seats = new List<Seat>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                #region BandALL
                BandALL.Add(ImageButton1);
                BandALL.Add(ImageButton2);
                BandALL.Add(ImageButton3);
                BandALL.Add(ImageButton4);
                BandALL.Add(ImageButton5);
                BandALL.Add(ImageButton6);
                BandALL.Add(ImageButton7);
                BandALL.Add(ImageButton8);
                BandALL.Add(ImageButton9);
                BandALL.Add(ImageButton10);
                BandALL.Add(ImageButton11);
                BandALL.Add(ImageButton12);
                BandALL.Add(ImageButton13);
                BandALL.Add(ImageButton14);
                BandALL.Add(ImageButton15);
                BandALL.Add(ImageButton16);
                BandALL.Add(ImageButton17);
                BandALL.Add(ImageButton18);
                BandALL.Add(ImageButton19);
                BandALL.Add(ImageButton20);
                BandALL.Add(ImageButton21);
                BandALL.Add(ImageButton22);
                BandALL.Add(ImageButton23);
                BandALL.Add(ImageButton24);
                BandALL.Add(ImageButton25);
                BandALL.Add(ImageButton26);
                BandALL.Add(ImageButton27);
                BandALL.Add(ImageButton28);
                BandALL.Add(ImageButton29);
                BandALL.Add(ImageButton30);
                BandALL.Add(ImageButton31);
                BandALL.Add(ImageButton32);
                BandALL.Add(ImageButton33);
                BandALL.Add(ImageButton34);
                BandALL.Add(ImageButton35);
                BandALL.Add(ImageButton36);
                BandALL.Add(ImageButton37);
                BandALL.Add(ImageButton38);
                BandALL.Add(ImageButton39);
                BandALL.Add(ImageButton40);
                BandALL.Add(ImageButton41);
                BandALL.Add(ImageButton42);
                BandALL.Add(ImageButton43);
                BandALL.Add(ImageButton44);
                BandALL.Add(ImageButton45);
                BandALL.Add(ImageButton46);
                BandALL.Add(ImageButton47);
                BandALL.Add(ImageButton48);
                BandALL.Add(ImageButton49);
                BandALL.Add(ImageButton50);
                BandALL.Add(ImageButton51);
                BandALL.Add(ImageButton52);
                BandALL.Add(ImageButton53);
                BandALL.Add(ImageButton54);
                BandALL.Add(ImageButton55);
                BandALL.Add(ImageButton56);
                BandALL.Add(ImageButton57);
                BandALL.Add(ImageButton58);
                BandALL.Add(ImageButton59);
                BandALL.Add(ImageButton60);
                BandALL.Add(ImageButton61);
                BandALL.Add(ImageButton62);
                BandALL.Add(ImageButton63);
                BandALL.Add(ImageButton64);
                BandALL.Add(ImageButton65);
                BandALL.Add(ImageButton66);
                BandALL.Add(ImageButton67);
                BandALL.Add(ImageButton68);
                BandALL.Add(ImageButton69);
                BandALL.Add(ImageButton70);
                BandALL.Add(ImageButton71);
                BandALL.Add(ImageButton72);
                BandALL.Add(ImageButton73);
                BandALL.Add(ImageButton74);
                BandALL.Add(ImageButton75);
                BandALL.Add(ImageButton76);
                BandALL.Add(ImageButton77);
                BandALL.Add(ImageButton78);
                BandALL.Add(ImageButton79);
                BandALL.Add(ImageButton80);
                BandALL.Add(ImageButton81);
                BandALL.Add(ImageButton82);
                BandALL.Add(ImageButton83);
                BandALL.Add(ImageButton84);

                #endregion
                customer_id = int.Parse(Session["customer"].ToString());
                foreach (var a in BandALL)
                {
                    a.ImageUrl = "~/Images/notbookedseat.png";
                }
                schedule_id = int.Parse(Session["schedule_id"].ToString());
                seats = DBConnectivty.Bookings(schedule_id);
                    if (seats.Count == 0)
                    {
                        foreach (var a in BandALL)
                        {
                            a.ImageUrl = "~/Images/notbookedseat.png";
                        }
                    }
                    else
                    {
                        for (int i = 0; i < seats.Count; i++)
                        {
                            foreach (var a in BandALL)
                            {
                                int seatno = seats[i].Seatid;
                                string id = "ImageButton" + seatno;
                                if (seats[i].Status == "booked")
                                {
                                    if ((seatno >= 1) && (seatno <= 24))
                                    {
                                        bookedseat = Panel1.FindControl(id) as ImageButton;
                                        bookedseat.ImageUrl = "~/Images/bookedseat.png";
                                        bookedseat.Enabled = false;
                                    }
                                    else if ((seatno >= 25) && (seatno <= 54))
                                    {
                                        bookedseat = Panel3.FindControl(id) as ImageButton;
                                        bookedseat.ImageUrl = "~/Images/bookedseat.png";
                                        bookedseat.Enabled = false;
                                    }
                                    else if ((seatno >= 55) && (seatno <= 84))
                                    {
                                        bookedseat = Panel4.FindControl(id) as ImageButton;
                                        bookedseat.ImageUrl = "~/Images/bookedseat.png";
                                        bookedseat.Enabled = false;
                                    }
                                    else
                                    {
                                        playtitle.Text = id;
                                    }
                                }
                                else
                                {
                                    a.ImageUrl = "~/Images/notbookedseat.png";
                                }
                            }
                        }
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton sourceImageButton = sender as ImageButton;
            string id = sourceImageButton.ID;
            string[] values = id.Split('n');
            int seatid = int.Parse(values[1]);
            //Label5.Text = seatid;
            string status = "booked";
            int band = 0;
            if ((seatid >= 1) && (seatid <= 24))
            {
                band = 1;
            }
            else if ((seatid >= 25) && (seatid <= 54))
            {
                 band = 2;
            }
            else if ((seatid >= 55) && (seatid <= 84))
            {
                 band = 3;

            }
            else
            {

            }
            double price = DBConnectivty.Loadprice(band, schedule_id);
            totalprice = double.Parse(Session["totalprice"].ToString());
            totalprice = totalprice + price;
            Session["totalprice"] = totalprice;
            Label5.Text = totalprice.ToString();
            bookedseats = int.Parse(Session["bookedseats"].ToString());
            bookedseats = bookedseats + 1;
            Session["bookedseats"] = bookedseats;

            Order order;
            order = DBConnectivty.ExistingOrder(customer_id);
            if (order == null)
            {
                Label5.Text = "No order";
                Label5.Visible = true;
                DBConnectivty.AddOrder(customer_id);
            }
            order = DBConnectivty.ExistingOrder(customer_id);
            int order_id = order.Orderid;
            Session["currentorder"] = order_id;
            int play_id = DBConnectivty.LoadThePlayID(schedule_id);
            int orderdetail_id;
            orderdetail_id = DBConnectivty.LoadTheOrderDetailID(order_id,play_id);
            if(orderdetail_id == 0)
            {
                DBConnectivty.AddOrderDetail(order_id, play_id, int.Parse(Session["bookedseats"].ToString()), int.Parse(Session["totalprice"].ToString()));
                orderdetail_id = DBConnectivty.LoadTheOrderDetailID(order_id, play_id);
            }
            else
            {
                int customerbookedseats = DBConnectivty.LoadNumOfBookedSeat(orderdetail_id);
                Label5.Text = customerbookedseats.ToString();
                customerbookedseats = customerbookedseats + int.Parse(Session["bookedseats"].ToString());
                int loadorderdetailprice = DBConnectivty.LoadOrderDetailPrice(orderdetail_id);
                loadorderdetailprice = loadorderdetailprice + int.Parse(Session["totalprice"].ToString());
                DBConnectivty.UpdateSeatandPrice(customerbookedseats, loadorderdetailprice, orderdetail_id);
            }

            DBConnectivty.AddBooking(seatid, schedule_id, status,orderdetail_id);
            Session["bookedseats"] = 0;
            Session["totalprice"] = 0;

            Response.Redirect("SelectSeat.aspx");
            

        }
    }
}