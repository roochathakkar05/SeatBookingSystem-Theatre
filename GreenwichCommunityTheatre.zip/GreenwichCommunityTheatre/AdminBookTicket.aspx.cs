﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminBookTicket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList2.DataSource = DBConnectivty.LoadInstitutionUser();
                DropDownList2.DataTextField = "instututionname";
                DropDownList2.DataValueField = "customer_id";
                DropDownList2.DataBind();

                DropDownList3.DataSource = DBConnectivty.LoadSingleUser();
                DropDownList3.DataTextField = "fname";
                DropDownList3.DataValueField = "customer_id";
                DropDownList3.DataBind();

                DropDownList4.DataSource = DBConnectivty.LoadWeeklySchedule();
                DropDownList4.DataTextField = "playname";
                DropDownList4.DataValueField = "id";
                DropDownList4.DataBind();
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedValue == "Individual")
            {
                Label1.Visible = false;
                DropDownList3.Visible = true;
                Label2.Visible = true;
                DropDownList2.Visible = false;
            }
            else
            {
                Label1.Visible = true;
                DropDownList3.Visible = false;
                Label2.Visible = false;
                DropDownList2.Visible = true;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int play_id;
            int customer_id;
            if (DropDownList1.SelectedValue == "Individual")
            {
                play_id = int.Parse(DropDownList4.SelectedValue);
                customer_id = int.Parse(DropDownList3.SelectedValue);
                Session["play_id"] = play_id;
                Session["customer_id"] = customer_id;
                Session["totalprice"] = 0;
                Session["bookedseats"] = 0;
                Response.Redirect("AdminSelectSeat.aspx");
            }
            else
            {
                play_id = int.Parse(DropDownList4.SelectedValue);
                customer_id = int.Parse(DropDownList2.SelectedValue);
                Session["play_id"] = play_id;
                Session["customer_id"] = customer_id;
                Session["totalprice"] = 0;
                Session["bookedseats"] = 0;
                Response.Redirect("AdminSelectSeat.aspx");
            }
        }
    }
}