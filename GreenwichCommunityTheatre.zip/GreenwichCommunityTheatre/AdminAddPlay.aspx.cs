﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminAddPlay : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text == "")
            {
                Label1.Text = "Enter Play Name";
            }
            else if(TextBox2.Text == "")
            {
                Label2.Text = "Enter Play Description";
            }
            else if(FileUpload1.HasFile == false)
            {
                Label3.Text = "Please upload an thumbnail image";
            }
            else if (FileUpload2.HasFile == false)
            {
                Label3.Text = "Please upload an main image";
            }
            else
            {
                string playname = TextBox1.Text;
                string playdesc = TextBox2.Text;
                string folderPath = Server.MapPath("~/Images/");
                if (!Directory.Exists(folderPath))
                {
                    //If Directory (Folder) does not exists Create it.
                    Directory.CreateDirectory(folderPath);
                }

                //Save the File to the Directory (Folder).
                FileUpload1.SaveAs(folderPath + Path.GetFileName(FileUpload1.FileName));
                string one = "~/Images/" + Path.GetFileName(FileUpload1.FileName);

                Label3.Text = one;
                string folderPath1 = Server.MapPath("~/Images/");
                if (!Directory.Exists(folderPath))
                {
                    //If Directory (Folder) does not exists Create it.
                    Directory.CreateDirectory(folderPath);
                }

                //Save the File to the Directory (Folder).
                FileUpload2.SaveAs(folderPath + Path.GetFileName(FileUpload2.FileName));
                string two = "~/Images/" + Path.GetFileName(FileUpload2.FileName);
                //Label2.Text = two;

                DBConnectivty.AddPlay(playname, playdesc, two, one);
                Label3.Text = "Play has been added";
                Response.Redirect("AdminViewPlays.aspx");
            }
        }
    }
}