﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Institution:Customer
    {
        private string instututionname;
        private string type;

        public Institution(int ci, string e,string instututionname, string type):base(ci,e)
        {
            this.instututionname = instututionname;
            this.type = type;
        }
        public Institution(int ci, string e,string p, string ph, string instututionname, string type) : base(ci,e,p,ph)
        {
            this.instututionname = instututionname;
            this.type = type;
        }

        public string Instututionname
        {
            get
            {
                return instututionname;
            }

            set
            {
                instututionname = value;
            }
        }

        public string Type
        {
            get
            {
                return type;
            }

            set
            {
                type = value;
            }
        }
    }
}