﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Seat
    {
        private int seatid;
        private string status;
        private int schedule_id;

        public int Seatid
        {
            get
            {
                return seatid;
            }

            set
            {
                seatid = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public int Schedule_id
        {
            get
            {
                return schedule_id;
            }

            set
            {
                schedule_id = value;
            }
        }

        public Seat(int seatid, string status, int schedule_id)
        {
            this.Seatid = seatid;
            this.Status = status;
            this.Schedule_id = schedule_id;
        }
    }
}