﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class PrintPage : System.Web.UI.Page
    {
        List<OrderDetail> cartdetails;
        string subprice;
        int grandtotal = 0;
        int price;
        int order_id;
        Shipping ship;
        string shipping;
        int shipprice;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                cartdetails = DBConnectivty.LoadOrderDetails(int.Parse(Session["PaidOrderId"].ToString()));
                for (int j = 0; j < cartdetails.Count; j++)
                {
                    createdetail(j);
                    if (j == 4)
                    {
                        price = 0;
                    }
                    else
                    {
                        price = int.Parse(cartdetails[j].Price.ToString());
                    }
                    grandtotal = grandtotal + price;
                    order_id = cartdetails[j].Order_id;
                    ship = DBConnectivty.ShippingType(cartdetails[j].Shipping_id);
                    shipping = ship.Type;
                    shipprice = int.Parse(ship.Price.ToString());
                    Label5.Text = cartdetails[j].Paymentstatus;
                    Label6.Text = Session["PaidOrderId"].ToString();

                }
                grandtotal = shipprice + grandtotal;
                Label3.Text = "£ " + shipprice.ToString();
                Label4.Text = shipping;

                Label1.Text = "£ " + grandtotal.ToString();
            }
        }
        public void createdetail(int i)
        {
            Label label = new Label();
            label.Text = cartdetails[i].Playname;
            Label label1 = new Label();
            label1.Text = cartdetails[i].Numberofseats.ToString();
            
            Label label2 = new Label();
            if (i == 4)
            {
                subprice = "£ " + 0;
                Label2.Visible = true;
                Label2.Text = "Discount coupon book for four plays get one free has been applied. ";
                label2.Text = subprice;
            }
            else
            {
                string subprice = "£ " + cartdetails[i].Price.ToString();
                label2.Text = subprice;
            }


            TableRow row = new TableRow();
            TableCell cell3 = new TableCell();
            cell3.Controls.Add(label);
            TableCell cell4 = new TableCell();
            cell4.Controls.Add(label1);
            TableCell cell5 = new TableCell();
            cell5.Controls.Add(label2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);
            row.Cells.Add(cell5);
            Table1.Rows.Add(row);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }
    }
}