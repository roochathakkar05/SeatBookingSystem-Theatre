﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminWeeklySchedule : System.Web.UI.Page
    {
        List<Schedule> Allplays;
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["customer"] == null)
            //{
            // Response.Redirect("Login.aspx");
            //}
            //else
            //{
            //int cust_id = int.Parse(Session["customer"].ToString());
            Allplays = DBConnectivty.LoadWeeklySchedule();
            if(Allplays.Count == 0)
            {
                Label1.Text = "No play on the schedule.";
                Table1.Visible = false;

            }
            if (Allplays.Count == 6)
            {
                Button3.Visible = false;
            }
            for (int i = 0; i < Allplays.Count; i++)
            {
                createshow(i);
            }
            // }
        }


        public void createshow(int i)
        {
            //creating controls
            Image imgb = new Image();
            imgb.Width = 100;
            imgb.Height = 100;
            Label NameOfPlay = new Label();
            NameOfPlay.Text = Allplays[i].Playname;
            NameOfPlay.Font.Size = 10;
            NameOfPlay.Font.Bold = false;
            Label Date = new Label();
            string _Date = Allplays[i].Date;
            DateTime dt = Convert.ToDateTime(_Date);
            string FDate = dt.ToString("dd-MMM-yyyy");
            Date.Text =FDate;
            Date.Font.Size = 10;
            Date.Font.Bold = false;
            Label Day = new Label();
            Day.Text = Allplays[i].Day;
            Day.Font.Size = 10;
            Day.Font.Bold = false;
            Label showtime = new Label();
            showtime.Text = Allplays[i].Showtime;
            showtime.Font.Size = 10;
            showtime.Font.Bold = false;

            //Inserting controls to the table
            TableRow row = new TableRow();
            TableCell cell1 = new TableCell();
            cell1.Width = 150;
            imgb.ImageUrl = Allplays[i].Playmainimage;
            cell1.Controls.Add(imgb);
            TableCell cell2 = new TableCell();
            cell2.Controls.Add(NameOfPlay);
            TableCell cell3 = new TableCell();
            cell3.Controls.Add(Date);
            TableCell cell4 = new TableCell();
            cell4.Controls.Add(Day);
            TableCell cell5 = new TableCell();
            cell5.Controls.Add(showtime);
            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);
            row.Cells.Add(cell5);
            Table1.Rows.Add(row);
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            DBConnectivty.ClearSchedule();
            Response.Redirect("AdminWeeklySchedule.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminCreateWeeklySchedule.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEditPricing.aspx");
        }
    }
}