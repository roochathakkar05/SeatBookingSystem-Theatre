﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminCreateWeeklySchedule : System.Web.UI.Page
    {
        int showslotid;
        int playid;
        string date;
        List<Show_slot> showslot;
        protected void Page_Load(object sender, EventArgs e)
        {
            showslot = DBConnectivty.LoadShowSlotCB();
            if (!IsPostBack)
            {
                DropDownList1.DataSource = DBConnectivty.LoadAllPlaysCB();
                DropDownList1.DataTextField = "playname";
                DropDownList1.DataValueField = "playid";
                DropDownList1.DataBind();

                DropDownList2.DataSource = showslot;
                DropDownList2.DataTextField = "day";
                DropDownList2.DataValueField = "showslotid";
                DropDownList2.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            date = Calendar1.SelectedDate.ToShortDateString();
            playid = int.Parse(DropDownList1.SelectedValue);
            showslotid = int.Parse(DropDownList2.SelectedValue);
            DBConnectivty.AddSchedule(playid, showslotid, date);
            Label1.Text = "success";
            Response.Redirect("AdminWeeklySchedule.aspx");
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            showslotid = int.Parse(DropDownList2.SelectedValue);
            int id = showslotid - 1;
            string day = showslot[id].Time;
            Label2.Text = day;

        }
    }
}