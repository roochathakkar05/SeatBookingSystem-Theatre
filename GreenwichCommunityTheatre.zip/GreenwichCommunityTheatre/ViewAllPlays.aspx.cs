﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class ViewAllPlays : System.Web.UI.Page
    {
        List<int> WatchedPlays;
        int cust_id;
        Play play;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                int cust_id = int.Parse(Session["customer"].ToString());
                WatchedPlays = DBConnectivty.LoadWatchedPlays(cust_id);
                for(int i = 0; i<WatchedPlays.Count; i++)
                {
                    int play_id = WatchedPlays[i];
                    play = DBConnectivty.LoadWatchedPlayDetails(play_id);
                    createshow();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button sourceButton = sender as Button;
            string id = sourceButton.ID;
            string[] values = id.Split('n');
            int playtoreview = int.Parse(values[1]);
            Session["ReviewPlayID"] = playtoreview;
           // Label1.Text = "Success";
           Response.Redirect("ReviewPlay.aspx");
        }

        public void createshow()
        {
            //creating controls
            Image imgb = new Image();
            imgb.Width = 100;
            imgb.Height = 100;
            Label NameOfPlay = new Label();
            NameOfPlay.Text = play.Playname;
            NameOfPlay.Font.Size = 10;
            NameOfPlay.Font.Bold = false;
            Label Description = new Label();
            Description.Font.Size = 10;
            Description.Font.Bold = false;
            Description.Text = play.Playdesc;

            Button btn = new Button();
            btn.ID = "btn" + play.Playid;
            btn.Text = "Review";
            btn.Click += Button1_Click;

            //Inserting controls to the table
            TableRow row = new TableRow();
            TableCell cell1 = new TableCell();
            cell1.Width = 150;
            imgb.ImageUrl = play.Playmainimage;
            cell1.Controls.Add(imgb);
            TableCell cell2 = new TableCell();
            cell2.Width = 500;
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(NameOfPlay);
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(Description);
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(new LiteralControl("<br />"));
            TableCell cell3 = new TableCell();
            cell3.Width = 150;
            cell3.Controls.Add(btn);
            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            Table1.Rows.Add(row);
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            Session["customer"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}