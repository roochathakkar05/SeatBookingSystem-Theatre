﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Show_slot
    {
        private int showslotid;
        private string day;
        private string time;

        public Show_slot(int showslotid, string day, string time)
        {
            this.showslotid = showslotid;
            this.day = day;
            this.time = time;
        }

        public int Showslotid
        {
            get
            {
                return showslotid;
            }

            set
            {
                showslotid = value;
            }
        }

        public string Day
        {
            get
            {
                return day;
            }

            set
            {
                day = value;
            }
        }

        public string Time
        {
            get
            {
                return time;
            }

            set
            {
                time = value;
            }
        }
    }
}