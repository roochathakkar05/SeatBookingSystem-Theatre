﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminViewOrders : System.Web.UI.Page
    {
        List<Order> orders;
        Institution insti;
        Individual indi;
        string customername;
        Shipping ship;
        string shipping;
        protected void Page_Load(object sender, EventArgs e)
        {
            orders = DBConnectivty.LoadAllorders();
            for (int i = 0; i < orders.Count; i++)
            {
                int cust_id = orders[i].Customerid;
                insti = DBConnectivty.InstitutionUser(cust_id);
                if (insti == null)
                {
                    indi = DBConnectivty.SingleUser(cust_id);
                    customername = indi.Fname + " " + indi.Lname;
                }
                else
                {
                    customername = insti.Instututionname;
                }
                int shipping_id = orders[i].Shippingid;
                ship = DBConnectivty.ShippingType(shipping_id);
                shipping = ship.Type;
                createshow(i);

            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Button sourceButton = sender as Button;
            string id = sourceButton.ID;
            string[] values = id.Split('n');
            int playtoreview = int.Parse(values[1]);
            Session["adminorderid"] = playtoreview;
            Label1.Text = "Success";
            Response.Redirect("AdminViewOrderDetails.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Button sourceButton = sender as Button;
            string id = sourceButton.ID;
            string[] values = id.Split('n');
            int playtoreview = int.Parse(values[1]);
            DBConnectivty.CompleteOrder(playtoreview);
            Label1.Text = "Success 1";
            Response.Redirect("AdminViewOrders.aspx");
        }
        public void createshow(int i)
        {
            //creating controls
            Label OrderId = new Label();
            OrderId.Text = orders[i].Orderid.ToString();
            OrderId.Font.Size = 12;
            OrderId.Font.Bold = true;
            Label CustomerName = new Label();
            CustomerName.Text = customername;
            CustomerName.Font.Size = 12;
            CustomerName.Font.Bold = false;
            Label shippingName = new Label();
            shippingName.Text = shipping;
            shippingName.Font.Size = 12;
            shippingName.Font.Bold = false;

            Button btn = new Button();
            btn.ID = "btn" + orders[i].Orderid.ToString();
            btn.Text = "View Order";
            btn.Click += Button1_Click;

            Button btn1 = new Button();
            btn1.ID = "shipn" + orders[i].Orderid.ToString();
            btn1.Text = "Complete";
            btn1.Click += Button2_Click;

            //Inserting controls to the table
            TableRow row = new TableRow();
            TableCell cell1 = new TableCell();
            cell1.Controls.Add(OrderId);
            TableCell cell2 = new TableCell();
            cell2.Controls.Add(CustomerName);
            TableCell cell3 = new TableCell();
            cell3.Controls.Add(shippingName);
            TableCell cell4 = new TableCell();
            cell4.Controls.Add(btn);
            TableCell cell5 = new TableCell();
            cell5.Controls.Add(btn1);
            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);
            row.Cells.Add(cell5);
            Table1.Rows.Add(row);
        }
    }
}