﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Shipping
    {
        private int shippingid;
        private string type;
        private double price;

        public int Shippingid
        {
            get
            {
                return shippingid;
            }

            set
            {
                shippingid = value;
            }
        }

        public string Type
        {
            get
            {
                return type;
            }

            set
            {
                type = value;
            }
        }

        public double Price
        {
            get
            {
                return price;
            }

            set
            {
               price = value;
            }
        }

        public Shipping(int shippingid, string type, double price)
        {
            this.shippingid = shippingid;
            this.type = type;
            this.price = price;
        }
    }
}