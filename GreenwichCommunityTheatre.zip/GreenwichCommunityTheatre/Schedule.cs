﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreenwichCommunityTheatre
{
    public class Schedule:Play
    {
        private string date;
        private string day;
        private string showtime;
        private int id;

        public Schedule(int id,int pi, string n, string d, string mi, string showtime, string day, string date) : base(pi, n, d, mi)
        {
            this.date = date;
            this.day = day;
            this.showtime = showtime;
            this.id = id;
        }

        public string Date
        {
            get
            {
                return date;
            }

            set
            {
                date = value;
            }
        }

        public string Day
        {
            get
            {
                return day;
            }

            set
            {
                day = value;
            }
        }

        public string Showtime
        {
            get
            {
                return showtime;
            }

            set
            {
                showtime = value;
            }
        }

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }
    }
}