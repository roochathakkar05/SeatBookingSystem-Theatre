﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminEditPricing : System.Web.UI.Page
    {
        List<Schedule> plays; 
        protected void Page_Load(object sender, EventArgs e)
        {
            plays = DBConnectivty.LoadWeeklySchedule();
            if (!IsPostBack)
            {
                DropDownList1.DataSource = plays;
                DropDownList1.DataTextField = "playname";
                DropDownList1.DataValueField = "id";
                DropDownList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text == "")
            {
                Label2.Text = "Please enter a price for Band A";
            }
            else if (TextBox2.Text == "")
            {
                Label3.Text = "Please enter a price for Band B";
            }
            else if (TextBox3.Text == "")
            {
                Label1.Text = "Please enter a price for Band C";
            }
            else
            {
                int Band_id = 0;
                int schedule = int.Parse(DropDownList1.SelectedValue.ToString());
                int priceA = int.Parse(TextBox1.Text);
                Band_id = 1;
                DBConnectivty.AddPrice(schedule, priceA, Band_id);
                int priceB = int.Parse(TextBox2.Text);
                Band_id = 2;
                DBConnectivty.AddPrice(schedule, priceB, Band_id);
                int priceC = int.Parse(TextBox3.Text);
                Band_id = 3;
                DBConnectivty.AddPrice(schedule, priceC, Band_id);
                //Label1.Text = "Success";
                Response.Redirect("AdminWeeklySchedule.aspx");
            }
        }
    }
}