﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class ViewPlay : System.Web.UI.Page
    {

        List<Play> SelectedPlay = new List<Play>();
        int playid;
        List<Review> review = new List<Review>();
        Review r = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["customer"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                int selectedurl = int.Parse(Session["playimgurl"].ToString());
                SelectedPlay = DBConnectivty.LoadSelectedPPPlay(selectedurl);

                for (int i = 0; i < SelectedPlay.Count; i++)
                {
                    Image1.ImageUrl = SelectedPlay[i].Playmainimage;
                    playtitle.Text = SelectedPlay[i].Playname;
                    Label1.Text = SelectedPlay[i].Playdesc;
                    playid = SelectedPlay[i].Playid;
                }
                r = DBConnectivty.LoadRating(playid);
                double rate = r.Rating;
                int rating = Convert.ToInt32(rate);
                if(rating == 1)
                {
                    Image2.Visible = true;
                }
                else if(rating == 2)
                {
                    Image2.Visible = true;
                    Image3.Visible = true;
                }
                else if (rating == 3)
                {
                    Image2.Visible = true;
                    Image3.Visible = true;
                    Image4.Visible = true;
                }
                else if (rating == 4)
                {
                    Image2.Visible = true;
                    Image3.Visible = true;
                    Image4.Visible = true;
                    Image5.Visible = true;

                }
                else if (rating == 5)
                {
                    Image2.Visible = true;
                    Image3.Visible = true;
                    Image4.Visible = true;
                    Image5.Visible = true;
                    Image6.Visible = true;
                }
                else 
                {
                    Label5.Text = "No Rating Available";
                }

                review = DBConnectivty.LoadReview(playid);
                if (review.Count == 0)
                {
                    Label2.Text = "No review available";
                    Label2.Visible = true;
                    Table1.Visible = false;
                }
                else
                {
                    for (int j = 0; j < review.Count; j++)
                    {
                        Label label11 = new Label();
                        label11.Width = 350;
                        label11.Text = review[j].Reviewwritten;
                        label11.Attributes.Add("align", "justify");
                        TableRow row = new TableRow();
                        TableCell cell2 = new TableCell();
                        cell2.Controls.Add(label11);
                        cell2.Controls.Add(new LiteralControl("<br />"));
                        cell2.Controls.Add(new LiteralControl("<br />"));
                        row.Cells.Add(cell2);
                        Table1.Rows.Add(row);
                    }
                }
            }
        }
        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            Session["customer"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}