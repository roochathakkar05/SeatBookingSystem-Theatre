﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class AdminViewPlays : System.Web.UI.Page
    {
            List<Play> Allplays;
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["customer"] == null)
            //{
            // Response.Redirect("Login.aspx");
            //}
            //else
            //{
            //int cust_id = int.Parse(Session["customer"].ToString());
            Allplays = DBConnectivty.LoadAllPlays();
                for (int i = 0; i < Allplays.Count; i++)
                {
                    createshow(i);
                }
           // }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button sourceButton = sender as Button;
            string id = sourceButton.ID;
            string[] values = id.Split('n');
            int playtoreview = int.Parse(values[1]);
            DBConnectivty.RemovePlay(playtoreview);
            // Label1.Text = "Success";
            Response.Redirect("AdminViewPlays.aspx");
        }

        public void createshow(int i)
        {
            //creating controls
            Image imgb = new Image();
            imgb.Width = 100;
            imgb.Height = 100;
            Label NameOfPlay = new Label();
            NameOfPlay.Text = Allplays[i].Playname;
            NameOfPlay.Font.Size = 10;
            NameOfPlay.Font.Bold = false;

            Button btn = new Button();
            btn.ID = "btn" + Allplays[i].Playid;
            btn.Text = "Remove";
            btn.Click += Button1_Click;

            //Inserting controls to the table
            TableRow row = new TableRow();
            TableCell cell1 = new TableCell();
            cell1.Width = 150;
            imgb.ImageUrl = Allplays[i].Playimage;
            cell1.Controls.Add(imgb);
            TableCell cell2 = new TableCell();
            cell2.Width = 500;
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(NameOfPlay);
            cell2.Controls.Add(new LiteralControl("<br />"));
            cell2.Controls.Add(new LiteralControl("<br />"));
            TableCell cell3 = new TableCell();
            cell3.Width = 150;
            cell3.Controls.Add(btn);
            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            Table1.Rows.Add(row);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminAddPlays.aspx");
        }
    }
}