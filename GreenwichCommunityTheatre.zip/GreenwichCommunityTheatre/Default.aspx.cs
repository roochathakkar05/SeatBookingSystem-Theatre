﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class _Default : Page
    {
        List<ImageButton> NowShowing = new List<ImageButton>();
        List<ImageButton> PopularPlays = new List<ImageButton>();
        List<Label> NowShowingLabel = new List<Label>();
        List<Label> PopularPlaysLabel = new List<Label>();
        List<Play> PP = new List<Play>();
        List<Play> NS = new List<Play>();
        protected void Page_Load(object sender, EventArgs e)
        {
            #region PopularPlays
            PopularPlays.Add(ImageButton1);
            PopularPlays.Add(ImageButton2);
            PopularPlays.Add(ImageButton3);
            PopularPlays.Add(ImageButton4);
            PopularPlays.Add(ImageButton5);
            PopularPlays.Add(ImageButton6);

            PopularPlaysLabel.Add(Label1);
            PopularPlaysLabel.Add(Label2);
            PopularPlaysLabel.Add(Label3);
            PopularPlaysLabel.Add(Label4);
            PopularPlaysLabel.Add(Label5);
            PopularPlaysLabel.Add(Label6);
            #endregion

            #region NowShowing
            NowShowing.Add(ImageButton7);
            NowShowing.Add(ImageButton8);
            NowShowing.Add(ImageButton9);
            NowShowing.Add(ImageButton10);
            NowShowing.Add(ImageButton11);
            NowShowing.Add(ImageButton12);

            NowShowingLabel.Add(Label7);
            NowShowingLabel.Add(Label8);
            NowShowingLabel.Add(Label9);
            NowShowingLabel.Add(Label10);
            NowShowingLabel.Add(Label11);
            NowShowingLabel.Add(Label12);
            #endregion

            PP = DBConnectivty.LoadPopularPlay();
            for(int i = 0; i < PP.Count; i++)
            {
                PopularPlays[i].ImageUrl = PP[i].Playimage;
                PopularPlaysLabel[i].Text = PP[i].Playname;
            }
            NS = DBConnectivty.LoadSchedule();
            for(int j = 0; j< NS.Count; j++)
            {
                NowShowing[j].ImageUrl = NS[j].Playimage;
                NowShowingLabel[j].Text = NS[j].Playname;
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton sourceImageButton = sender as ImageButton;
            string url = sourceImageButton.ImageUrl;
            int x = DBConnectivty.LoadSelectedPlay(url);
            Session["playimgurl"] = x;
            Response.Redirect("ViewPlay.aspx");
        }

        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton sourceImageButton1 = sender as ImageButton;
            string url1 = sourceImageButton1.ImageUrl;
            int x1 = DBConnectivty.LoadSelectedPlay(url1);
            Session["playimgurlNS"] = x1;
            Response.Redirect("ViewSelectedPageNS.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllPlays.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}