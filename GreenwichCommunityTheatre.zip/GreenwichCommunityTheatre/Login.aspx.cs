﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GreenwichCommunityTheatre
{
    public partial class Login : System.Web.UI.Page
    {
        string email;
        string password;
        string checkemail = "";
        string checkpass = "";
        int checkid;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text == "")
            {
                Label1.Text = "Please enter your registered email.";
                Label1.Visible = true;
                Label1.ForeColor = Color.Red;
            }
            if(TextBox2.Text == "")
            {
                Label1.Text = "Please enter your password.";
                Label1.Visible = true;
                Label1.ForeColor = Color.Red;
            }
            else
            {
                email = TextBox1.Text;
                password = TextBox2.Text;
                List<Customer> cust = new List<Customer>();
                cust = DBConnectivty.Login(email, password);
                foreach(var c in cust)
                {
                    checkemail = c.Customer_email;
                    checkpass = c.Customer_pass;
                    checkid = c.Customer_id;
                }
                if ((checkemail == email))
                {
                    if((checkpass == password))
                    {
                        Label3.Visible = true;
                        Label3.ForeColor = Color.FromArgb(51, 204, 51);
                        Label3.Text = "Login is successful";
                        Session["customer"] = checkid;
                        Label1.Text = Session["customer"].ToString();
                        Response.Redirect("HomePage.aspx");
                    }
                    else
                    {
                        Label3.ForeColor = Color.Red;
                        Label3.Visible = true;
                        Label3.Text = "The email or password is incorrect";
                    }
                }
                else
                {
                    Label3.ForeColor = Color.Red;
                    Label3.Visible = true;
                    Label3.Text = "The email or password is incorrect";
                }
            }
        }
    }
}